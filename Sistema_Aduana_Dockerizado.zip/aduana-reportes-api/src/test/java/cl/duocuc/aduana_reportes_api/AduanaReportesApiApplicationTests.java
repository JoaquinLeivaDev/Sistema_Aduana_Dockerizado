package cl.duocuc.aduana_reportes_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AduanaReportesApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
